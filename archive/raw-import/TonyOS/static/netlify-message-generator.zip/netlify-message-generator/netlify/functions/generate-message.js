exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_API_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: 'API key not configured' }) };
  }

  try {
    const data = JSON.parse(event.body);
    const { company, industry, state, fit, relationship, reason, contactName } = data;

    if (!company) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Company name required' }) };
    }

    const relationshipContext = {
      'new': 'This is a first-time outreach to a prospective customer who has never worked with Natoli.',
      'existing': 'This is an existing customer. The goal is to deepen the relationship and explore additional needs.',
      'lapsed': 'This customer has not ordered in 12+ months. The goal is re-engagement without pressure.'
    };

    const prompt = `You are a professional sales copywriter for Natoli Engineering Company, the world leader in tablet compression tooling and equipment for pharmaceutical, nutraceutical, and industrial tablet manufacturing.

COMPANY CONTEXT:
- Company: ${company}
- Industry: ${industry || 'manufacturing'}
- Location: ${state || 'USA'}
- Natoli Fit: ${fit || 'Engineering'}
${reason ? `- Why they need Natoli: ${reason}` : ''}
${contactName ? `- Contact Name: ${contactName}` : ''}

RELATIONSHIP: ${relationshipContext[relationship] || relationshipContext['new']}

NATOLI TONE STANDARDS (MANDATORY):
1. Calm, credible, manufacturing-first language
2. NO marketing hype, buzzwords, or excitement
3. NO pressure tactics or urgency
4. Soft CTAs only ("happy to discuss", "worth a conversation")
5. Written for experienced manufacturing professionals who hate being sold to
6. Subject lines should be boring/professional, not clickbait

Generate a personalized outreach email. The email should:
- Be 90-130 words
- Reference their specific industry context
- Mention relevant Natoli capabilities (tooling, tablet presses, formulation support, etc.)
- Feel like it was written by someone who understands their world
- End with a soft, no-pressure CTA

Respond in this exact JSON format:
{
  "subject": "Professional subject line here",
  "body": "Email body here"
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
        max_tokens: 500
      })
    });

    if (!response.ok) {
      const err = await response.json();
      return { statusCode: 500, body: JSON.stringify({ error: err.error?.message || 'OpenAI error' }) };
    }

    const result = await response.json();
    const content = result.choices[0].message.content;

    const jsonMatch = content.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(jsonMatch[0]);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(parsed)
    };

  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
